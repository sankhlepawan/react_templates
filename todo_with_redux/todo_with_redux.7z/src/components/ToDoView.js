import React, { Component } from 'react';
import { removeTodoAction } from '../actions/actions';
import { connect } from 'react-redux';

class ToDoView extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showEdit : [],
            todos: this.props.todos,
            updatedTodo:''
        }
        this.removeToDoFromList = this.removeToDoFromList.bind(this);
        this.editTodoItem = this.editTodoItem.bind(this);
        this.updateTodoItem = this.updateTodoItem.bind(this);
        // this.onToDoChange = this.onToDoChange.bind(this);
    }

    removeToDoFromList(item) {
        this.props.removeToDo(item);
    }

    editTodoItem(args) {
       this.state.showEdit[args] = true;
       console.log(this.state.showEdit);
        this.setState({
            showEdit: this.state.showEdit 
        });
        
    }

    updateTodoItem(index) {
        this.state.showEdit[index] = false;
        this.state.todos[index] = this.state.updatedTodo;
        this.setState({
            showEdit: this.state.showEdit,
            todos: this.state.todos
        });
    }

    onToDoChange(ev) {
        let newValue = ev.target.value;
        console.log(newValue);
        this.setState({
            updatedTodo:newValue
        });
        
    }

    render() { 
        return ( 
            <ul>
            {
                
             this.props.todos.map((item,index) => (
                <li key={index} className="row" >
                
                    <span className={"col-sm-3 padding-5px"} >
                     { !this.state.showEdit[index] ? <span>{item}</span> : <input type="text" value={item} onChange={(ev) => this.onToDoChange(ev) }></input> }
                    </span>
                    
                    <span className="col-sm-3"></span> 
                    <span className="col-sm-3">
                        <button className="btn btn-danger btn-sm" onClick={ this.removeToDoFromList.bind(null,item) } >Remove</button>
                        <span className="col-sm-1"></span>
                        <button className="btn btn-primary btn-sm" onClick={ !this.state.showEdit[index] ? this.editTodoItem.bind(null,index) : this.updateTodoItem.bind(null,index,item) } > {!this.state.showEdit[index]  ? 'Edit' : 'Update' }</button>
                    </span>
                </li>
            ))
            }
            </ul>
         );
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        removeToDo: (todoIndex) => dispatch(removeTodoAction(todoIndex))
    }
}

const mapStateToProps = (state) => {
    return {
       todos: state.todos,
     }
   }

export default connect(mapStateToProps, mapDispatchToProps)(ToDoView);